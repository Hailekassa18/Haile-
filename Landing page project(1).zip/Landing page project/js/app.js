// main starter function to pull elements from html

const nav = document.querySelector('.nav')
const sections = document.querySelectorAll('section');

//append the nav links with their corresponding sections. Added section ids as hrefs.
 sections.forEach(section => {
    const id = section.id;
    const data = section.dataset.nav;
    nav.innerHTML += `<li><a class="menu__link" href="index.html#${id}">${data}</a></li>`
    });

    //appends active class on given view port on a given event listner
window.addEventListener('scroll', () => {
    sections.forEach(section => {
        const scrollPosition = Math.floor(section.getBoundingClientRect().top)
        section.classList.remove('your-active-class');
        section.style.cssText = "background-color: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%);";
        if(scrollPosition < 155 && scrollPosition >= -155){
            section.classList.add('your-active-class');
            section.style.cssText = "background-color: blue;";
        }
    });
});
