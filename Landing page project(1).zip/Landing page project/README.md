Project Title: Landing Page Project

Demo- Preview

Table of contents

Description
Landing page and implementation of DOM to make a given page intractive

usage

Requirments
    Active pages have been higlighted when a scrolling even is triggered
    CSS styles have been implemented on active sections on Viewport
    Navigation bar has been added to all sections with an active link
    A responsve layout inplemented for all devises
     .getBoundingClientRect() built-in function. is implemented